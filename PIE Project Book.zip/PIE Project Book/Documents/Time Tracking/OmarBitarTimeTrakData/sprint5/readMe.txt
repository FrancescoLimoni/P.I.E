the App I used to trak my hours is called ATracker.
I traked all tasks that I did this semester using this app.
please refer to the PNG image to see a pie chart of how my time was managed.


"ruby project" is the time I spent working on the pie app.


you can find the app via the link below:-
https://play.google.com/store/apps/details?id=com.wonderapps.ATracker&hl=en_US