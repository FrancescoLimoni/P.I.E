the App I used to trak my hours is called ATracker.
I traked all tasks that I did this semester using this app.
please refer to the PNG image to see a pie chart of how my time was managed.

"website" and "ruby project" items are related to software devolpment class.
"ruby project" is the time I spent doing the pie app.
"website" is the time I spent doing docker and linux system.

you can find the app via the link below:-
https://play.google.com/store/apps/details?id=com.wonderapps.ATracker&hl=en_US